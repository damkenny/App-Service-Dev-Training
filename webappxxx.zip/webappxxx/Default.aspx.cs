﻿using System;
using System.Data;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Submit_Click(object sender, EventArgs e)
    {
        string selectedFruit = "Kiwi";
        string fruitAvail = "Begin";

        //Get users fruit choice
        if (rbApples.Checked)
        {
            selectedFruit = "Apples";
        }
        else if (rbBananas.Checked)
        {
            selectedFruit = "Bananas";
        }
        else if (rbPears.Checked)
        {
            selectedFruit = "Pears";
        }
        else if (rbOranges.Checked)
        {
            selectedFruit = "Oranges";
        }
        else if (rbGrapes.Checked)
        {
            selectedFruit = "Grapes";
        }
        else if (rbCherries.Checked)
        {
            selectedFruit = "Cherries";
        }

        //Get database configuration from app settings
        string connectionString = null;
        string SQLLocale = System.Configuration.ConfigurationManager.AppSettings["SQLLocale"];
        if (SQLLocale == "1")
        {
            connectionString = System.Configuration.ConfigurationManager.AppSettings["SQLSite"];
        }
        else
        {
            connectionString = Microsoft.Azure.CloudConfigurationManager.GetSetting("SQLSite");
        }

        string queryString = "SELECT * FROM Produce where Fruit = '" + selectedFruit + "';";

        try
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Create the Command and Parameter objects.
                SqlCommand command = new SqlCommand(queryString, connection);
                SqlDataAdapter da = new SqlDataAdapter(command);
                SqlCommandBuilder cb = new SqlCommandBuilder(da);

                DataSet dsProduce = new DataSet("Produce");
                da.Fill(dsProduce, "Produce");

                string fType = dsProduce.Tables[0].Rows[0]["Fruit"].ToString();
                int fAmount = int.Parse(dsProduce.Tables[0].Rows[0]["Amount"].ToString());
                string fSize = dsProduce.Tables[0].Rows[0]["Quantity"].ToString();
                fruitAvail = String.Format("There are {0} {1} {2} left. I have saved one for you.", fAmount, fType, fSize);

                //remove one fruit item
                fAmount = fAmount - 1;

                queryString = "UPDATE Produce SET Amount=" + fAmount + " where Fruit='" + fType + "'";
                command = new SqlCommand(queryString, connection);
                command.ExecuteNonQuery();
            }
        }
        catch (Exception ex)
        {
            //fruitAvail =  "I'm sorry but I can't access the store right now";
            //fruitAvail = connectionString;
            fruitAvail = ex.Message.ToString();


        }

        lbResult.Text = fruitAvail;
    }
}
